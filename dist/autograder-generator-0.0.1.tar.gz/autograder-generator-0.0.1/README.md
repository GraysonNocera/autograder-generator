# autograder-generator

ECE 264 utility for generating autograder files.