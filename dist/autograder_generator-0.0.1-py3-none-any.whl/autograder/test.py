

def do_thing():
  print("hello, world")